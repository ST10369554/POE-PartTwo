1. Unzip the the folder "ST10369554_POE"
2. Open the folder "ST10369554_POE"
3. Open the "Ingredient.cs", "Step.cs", "Recipe.cs", "MainWindow.xaml", "MainWindow.xaml.cs", "IngredientWindow.xaml", "IngredientWindow.xaml.cs", 
 "StepWindow.xaml" and "StepWindow.xaml.cs" files using Visual studio 2022
4. Run it
5. The following are the buttons and a textblock the system will display and tell the user what to enter and the user must enter their 
input:

-Recipe name(textblock)

-Save Recipe

-Add Ingredient
When clicking the Add Ingredient button, it displays the ingredient window where you enter the ingredient
name, quantity, unit, calories and food group.

-Add Step
When clicking the Add Step button, it displays step window where you add your steps. If you want to add
another step you click it again

A Recipe filters heading with the following filtering features under it:

-Ingredient Name

-Food Group

-Maximum Calories(Slider)
The amount of calories increase as the more you slide it to the right.

-Apply filters (button)

After are the other buttons and a textblock:

-Show Recipe

-Scale Factor(textblock)

-Scale Recipe

-ResetQuantites