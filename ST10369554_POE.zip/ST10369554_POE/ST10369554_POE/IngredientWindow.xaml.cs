﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ST10369554_POE.Models;

namespace ST10369554_POE
{
    /// <summary>
    /// Interaction logic for IngredientWindow.xaml
    /// </summary>
    public partial class IngredientWindow : Window
    {
        public Ingredient Ingredient { get; private set; }
        public IngredientWindow()
        {
            InitializeComponent();
            PopulateFoodGroupComboBox();
        }
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            var name = NameTextBox.Text;
            var quantity = double.Parse(QuantityTextBox.Text);
            var unit = UnitTextBox.Text;
            var calories = double.Parse(CaloriesTextBox.Text);
            var foodGroup = FoodGroupComboBox.SelectedItem.ToString();

            Ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
            DialogResult = true;
        }
        private void PopulateFoodGroupComboBox()
        {
            var foodGroups = new List<string> { "Vegetables", "Fruits", "Grains", "Proteins", "Diary", "Sauce", "Sweets", "Beverages" };
            FoodGroupComboBox.ItemsSource = foodGroups;
        }
    }
}
