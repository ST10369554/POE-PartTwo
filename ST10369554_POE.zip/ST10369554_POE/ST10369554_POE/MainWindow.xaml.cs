﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ST10369554_POE.Models;

namespace ST10369554_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();
        private Recipe currentRecipe;
        public MainWindow()
        {
            InitializeComponent();
            PopulateFoodGroupComboBox();
        }
        private void AddIngred_Click(object sender, RoutedEventArgs e)
        {
            var ingredientWindow = new IngredientWindow();
            if (ingredientWindow.ShowDialog() == true)
            {
                var ingredient = ingredientWindow.Ingredient;
                currentRecipe?.AddIngred(ingredient.Names, ingredient.Quantities, ingredient.Units, ingredient.Calories, ingredient.FoodGroup);
            }
        }
        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            var stepWindow = new StepWindow();
            if (stepWindow.ShowDialog() == true)
            {
                var step = stepWindow.Step;
                currentRecipe?.AddStep(step.Description);
            }
        }
        private void SaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            var recipeName = RecipeNameTextBox.Text;
            if (!string.IsNullOrEmpty(recipeName))
            {
                currentRecipe = new Recipe(recipeName);
                recipes.Add(currentRecipe);

                currentRecipe.ExceededRecipeCalories += (name, calories) =>
                {
                    MessageBox.Show($"Warning: Recipe '{name}' has {calories} calories. It exceeds 300 calories.");
                };

                currentRecipe.CalorieCheck();
                RefreshRecipeList();
            }
        }
        private void ShowRecipe_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectedRecipe)
            {
                var ingredientDetails = selectedRecipe.ingredients.Select(i => $"{i.Quantities} {i.Units} of {i.Names} ({i.Calories} calories, {i.FoodGroup})");

                var stepDetails = selectedRecipe.steps.Select((s, index) => $"{index + 1}. {s.Description}");

                MessageBox.Show($"Recipe: {selectedRecipe.RecipeName}\n" + $"Ingredient:\n {string.Join("\n", ingredientDetails)}\n" +
                    $"Steps:\n {string.Join("\n", stepDetails)}");
            }
        }
        private void AppFilters_Click(object sender, RoutedEventArgs e)
        {
            var filterRecipes = recipes.AsEnumerable();

            if (!string.IsNullOrEmpty(IngredientFilterTextBox.Text)) 
            {
                filterRecipes = filterRecipes.Where(r => r.ingredients.Any(i => i.Names.Contains(IngredientFilterTextBox.Text, StringComparison.OrdinalIgnoreCase)));
            }
            if (FoodGroupComboBox.SelectedItem != null) 
            { 
                string selectFoodGroup = FoodGroupComboBox.SelectedItem.ToString();
                filterRecipes = filterRecipes.Where(r => r.ingredients.Any(i => i.FoodGroup == selectFoodGroup));
            }
            filterRecipes = filterRecipes.Where(r => r.CalculateTotalCalories() <= CaloriesSlider.Value);

            RecipesListBox.ItemsSource = filterRecipes.OrderBy(r => r.RecipeName).ToList();
        }
        private void PopulateFoodGroupComboBox()
        {
            var foodGroups = new List<string> { "Vegetables", "Fruits", "Grains", "Proteins", "Diary", "Sauce", "Sweets", "Beverages"};
            FoodGroupComboBox.ItemsSource = foodGroups;
        }
        private void RefreshRecipeList()
        {
            RecipesListBox.ItemsSource = recipes.OrderBy(r => r.RecipeName).ToList();
        }
        private void RecipeScale_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectRecipe)
            {
                if (double.TryParse(ScaleFactorTextBox.Text, out double scale))
                {
                    selectRecipe.RecipeScale(scale);
                    MessageBox.Show($"Recipe '{selectRecipe.RecipeName}' scaled by a factor of {scale}.");
                    selectRecipe.ShowRecipe();
                }
                else
                {
                    MessageBox.Show("Invalid. Enter a valid number.");
                }
            }
        }
        private void ResetQuantities_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem is Recipe selectRecipe)
            {
                selectRecipe.ResetQuantities();
                MessageBox.Show($"Quantities for recipe '{selectRecipe.RecipeName}' have been reset to their original values.");
                selectRecipe.ShowRecipe();
            }
        }
    }
}