﻿// See https://aka.ms/new-console-template for more information
using System;

namespace Recipe
{
    class ingredient
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of ingredients: ");
            int numIngredients = Convert.ToInt32(Console.ReadLine());

            string[] ingredName = new string[numIngredients];
            double[] ingredQuantity = new double[numIngredients];
            string[] ingredUnit = new string[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"\n Enter ingredient details{i + 1}:");
                Console.Write("Name: ");
                ingredName[i] = Console.ReadLine();
                Console.Write("Quantity: ");
                ingredQuantity[i] = Convert.ToDouble(Console.ReadLine());
                Console.Write("Unit of Measurement: ");
                ingredUnit[i] = Console.ReadLine();
            }

            Console.Write("\nEnter number of steps: ");
            int numSteps = Convert.ToInt32(Console.ReadLine());

            string[] recipeSteps = new string[numSteps];

            for (int i = 0;i < numSteps; i++) 
            {
                Console.Write($"Enter step {i + 1}: ");
                recipeSteps[i] = Console.ReadLine();
            }

            Console.WriteLine("\nRecipe Details:");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"{ingredQuantity[i]} {ingredUnit[i]} of {ingredName[i]}");
            }

            Console.WriteLine("\nSteps:");
            for(int i = 0; i < numSteps; i++) 
            {
                Console.WriteLine($"{i + 1}. {recipeSteps[i]}");
            }
        }
    }
}